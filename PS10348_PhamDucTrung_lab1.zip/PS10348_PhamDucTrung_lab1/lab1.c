#include <stdio.h>;

void main(){
    printf("Pham Duc Trung");
    printf("PS10348");
}