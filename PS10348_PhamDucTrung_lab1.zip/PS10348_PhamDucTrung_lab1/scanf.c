#include <stdio.h>;

void main(){
   int a = 40;
   int b = 51;
   int c = a++ + ++b;
   printf("ket qua la %d", c++);
    
}