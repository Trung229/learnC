// khai bao thu vien stdio.h
#include <stdio.h>
#define DATA 10
int main(){
	/* In ra man hinh chuoi:
	Hello, FPT Polytechnic */
    int a;
    int b;
    a = 10;
    b = 20;
    int result = a + b;
    printf("gia tri cua a: %d\n",a);
    printf("gia tri cua b: %d\n",b);
    printf("gia tri cua result: %d\n",result);
    printf("gia tri cua DATA: %d\n",DATA);
	return 0;
}